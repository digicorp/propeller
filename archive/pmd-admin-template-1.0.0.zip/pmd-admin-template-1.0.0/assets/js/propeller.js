/*!
 * Propeller v1.0.0 (http://propeller.in)
 * Copyright 2016-2017 Digicorp, Inc.
 * Licensed under MIT (http://propeller.in/LICENSE)
 */

$( document ).ready(function() {
	// Propeller form ------------------------------------------------------//

	// paper input
	$(".pmd-textfield-focused").remove();
	$(".pmd-textfield .form-control").after('<span class="pmd-textfield-focused"></span>');
	
	// floating label
	$('.pmd-textfield input.form-control').each(function () {
		if($(this).val() != ""){
			$(this).closest('.pmd-textfield').addClass("pmd-textfield-floating-label-completed");
	  	}
	});
	
	// floating label animation
	$("body").on("focus",".pmd-textfield .form-control",function(){
    	$(this).closest('.pmd-textfield').addClass("pmd-textfield-floating-label-active pmd-textfield-floating-label-completed");
    });
	
	// remove floating label animation
	$("body").on("focusout",".pmd-textfield .form-control",function(){
    	if($(this).val() === ""){
        	$(this).closest('.pmd-textfield').removeClass("pmd-textfield-floating-label-completed");
      	}
		$(this).closest('.pmd-textfield').removeClass("pmd-textfield-floating-label-active");
    });

	// custam check box
	$('.pmd-checkbox input').after('<span class="pmd-checkbox-label">&nbsp;</span>');
	
	// custam radio box
	$('.pmd-radio input').after('<span class="pmd-radio-label">&nbsp;</span>');
	
	
	// dropdown Animation elements ----------------------------------------------------//
	(function($) {
		$('.dropdown-menu').wrap( "<div class='pmd-dropdown-menu-container'></div>" );
		$('.dropdown-menu').before('<div class="pmd-dropdown-menu-bg"></div>');
		
		var dropdown = $('.dropdown');
		var pmdsidebardropdown = function() {
			if ( $(window).width() < 767) {
				// Add slidedown animation to dropdown
				
				dropdown.off('show.bs.dropdown');
				dropdown.on('show.bs.dropdown', function(e){
					var that = $(this).find('.dropdown-menu');
					var w = that.outerWidth();
					var h = that.outerHeight();
					var dcdmc = that.closest('.pmd-dropdown-menu-container');
					var dcdmbg = dcdmc.find('.pmd-dropdown-menu-bg');
					$dataSidebar = $(this).find('.dropdown-toggle').attr("data-sidebar");
					var dropdowncenter = that.hasClass('pmd-dropdown-menu-center');

					if ( $dataSidebar == 'true') {
						that.first().stop(true, true).slideDown(300);
						$(this).addClass('pmd-sidebar-dropdown');
					} else if ( dropdowncenter ) {
						$('.dropdown-menu').removeAttr('style');
						that.first().stop(true, true).slideDown(300);
					} else {
					 // that.first().stop(true, true).show();
						dcdmc.css({'width':w + 'px', 'height':h + 'px'}, 0);
						dcdmc.find('.pmd-dropdown-menu-bg').css({'width':w + 'px', 'height':h + 'px'});
						that.css("clip","rect(0 "+w+"px "+h+"px 0)");
						if( that.hasClass('dropdown-menu-right')){
							dcdmbg.addClass('pmd-dropdown-menu-bg-right');
							dcdmc.css({"right":"0", "left":"auto"})
						} else if (that.hasClass('pmd-dropdown-menu-top-left')){
							dcdmbg.addClass('pmd-dropdown-menu-bg-bottom-left');
						} else if (that.hasClass('pmd-dropdown-menu-top-right')){
							dcdmbg.addClass('pmd-dropdown-menu-bg-bottom-right');
							dcdmc.css({"right":"0", "left":"auto"})
						} 
					}
					
				});
				
				// Add slideup animation to dropdown
				dropdown.off('hide.bs.dropdown');
				dropdown.on('hide.bs.dropdown', function(e){
					$dataSidebar = $(this).find('.dropdown-toggle').attr("data-sidebar");
					var dropdowncenter = $(this).find('.dropdown-menu').hasClass('pmd-dropdown-menu-center');
					var that = $(this).find('.dropdown-menu');
					var w = that.outerWidth();
					var h = that.outerHeight();
					var dcdmc = that.closest('.pmd-dropdown-menu-container');
					var dcdmbg = dcdmc.find('.pmd-dropdown-menu-bg');
					if ($dataSidebar == 'true') {
						that.first().stop(true, true).slideUp(300);
					} else if (dropdowncenter) {
						$('.dropdown-menu').removeAttr('style');
						that.first().stop(true, true).slideUp(300);
					} else {
						that.css("clip","rect(0 0 0 0)");
						dcdmc.removeAttr('style');
						dcdmbg.removeAttr('style');
						if(that.hasClass('dropdown-menu-right')){
							that.css("clip","rect(0 "+w+"px 0 "+w+"px)");
						} else if (that.hasClass('pmd-dropdown-menu-top-right')){
							that.css("clip","rect(0 "+w+"px 0 "+w+"px)");
						} 
					}
				});
			} else {
			
				// Add slidedown animation to dropdown
				$('.dropdown-menu').removeAttr('style');
				dropdown.off('show.bs.dropdown');
				dropdown.on('show.bs.dropdown', function(e){
				//	$('.dropdown-menu').css({'clip':'rect(0 0 0 0)'});
					$dataSidebar = $(this).find('.dropdown-toggle').attr("data-sidebar");
					var hassidebar = $(this).closest('.pmd-sidebar').hasClass('pmd-sidebar');
					var dropdowncenter = $(this).find('.dropdown-menu').hasClass('pmd-dropdown-menu-center');
					var that = $(this).find('.dropdown-menu');
					var w = that.outerWidth();
					var h = that.outerHeight();
					var dcdmc = that.closest('.pmd-dropdown-menu-container');
					var dcdmbg = dcdmc.find('.pmd-dropdown-menu-bg');
					if (hassidebar) {
						that.first().stop(true, true).slideDown();
					} else if ( dropdowncenter ) {
						$('.dropdown-menu').removeAttr('style');
						that.first().stop(true, true).slideDown();
					} else {
						dcdmc.css({'width':w + 'px', 'height':h + 'px'}, 200);
						dcdmbg.css({'width':w + 'px', 'height':h + 'px'});
						if( that.hasClass('dropdown-menu-right')){
							that.css("clip","rect(0 "+w+"px "+h+"px 0)");
							dcdmbg.addClass('pmd-dropdown-menu-bg-right');
							dcdmc.css({"right":"0", "left":"auto"})
						} else if (that.hasClass('pmd-dropdown-menu-top-left')){
							that.css("clip","rect(0 "+w+"px "+h+"px 0)");
							dcdmbg.addClass('pmd-dropdown-menu-bg-bottom-left');
						} else if (that.hasClass('pmd-dropdown-menu-top-right')){
							that.css("clip","rect(0 "+w+"px "+h+"px 0)");
							dcdmbg.addClass('pmd-dropdown-menu-bg-bottom-right');
							dcdmc.css({"right":"0", "left":"auto"})
						} else {
							that.css("clip","rect(0 "+w+"px "+h+"px 0)");
						}
					}
				});
				
				// Add slideup animation to dropdown
				dropdown.off('hide.bs.dropdown');
				dropdown.on('hide.bs.dropdown', function(e){
					$dataSidebar = $(this).find('.dropdown-toggle').attr("data-sidebar");
					var hassidebar = $(this).closest('.pmd-sidebar').hasClass('pmd-sidebar');
					var dropdowncenter = $(this).find('.dropdown-menu').hasClass('pmd-dropdown-menu-center');
					var that = $(this).find('.dropdown-menu');
					var w = that.outerWidth();
					var h = that.outerHeight();
					var dcdmc = that.closest('.pmd-dropdown-menu-container');
					var dcdmbg = dcdmc.find('.pmd-dropdown-menu-bg');
					if (hassidebar) {
						that.first().stop(true, true).slideUp(300);
					} else if ( dropdowncenter ) {
						$('.dropdown-menu').removeAttr('style');
						that.first().stop(true, true).slideUp(300);
					} else {
						that.css("clip","rect(0 0 0 0)");
						dcdmc.removeAttr('style');
						dcdmbg.removeAttr('style');
						if(that.hasClass('dropdown-menu-right')){
							that.css("clip","rect(0 "+w+"px 0 "+w+"px)");
						} else if (that.hasClass('pmd-dropdown-menu-top-right')){
							that.css("clip","rect(0 "+w+"px 0 "+w+"px)");
						} 
					}
				});	
			}
		}
		
		pmdsidebardropdown();
		
		$(window).resize(function(){
			pmdsidebardropdown();
		});
		
	})(jQuery);
	
	
	// Ripple Effect -----------------------------------------------------------------//
	 $(".pmd-ripple-effect").on('mousedown touchstart', function(e) {
		var rippler = $(this);
		$('.ink').remove();
		// create .ink element if it doesn't exist
		if(rippler.find(".ink").length == 0) {
			rippler.append("<span class='ink'></span>");
		}
		var ink = rippler.find(".ink");
		// prevent quick double clicks
		ink.removeClass("animate");
		// set .ink diametr
		if(!ink.height() && !ink.width())
		{
			var d = Math.max(rippler.outerWidth(), rippler.outerHeight());
			ink.css({height: d, width: d});
		}
		// get click coordinates
		var x = e.pageX - rippler.offset().left - ink.width()/2;
		var y = e.pageY - rippler.offset().top - ink.height()/2;
		// set .ink position and add class .animate
		ink.css({
		  top: y+'px',
		  left:x+'px'
		}).addClass("animate");
		
		setTimeout(function(){ 
			ink.remove();
		}, 1500);
	})
	
	//-- Checkbox Ripple Effect --//
	$(".pmd-checkbox-pmd-ripple-effect").on('mousedown', function(e) {
		var rippler = $(this);
		$('.ink').remove();
		// create .ink element if it doesn't exist
		if(rippler.find(".ink").length == 0) {
			rippler.append('<span class="ink"></span>');
		}
		var ink = rippler.find(".ink");
		// prevent quick double clicks
		ink.removeClass("animate");
		// set .ink diametr
		if(!ink.height() && !ink.width())
		{
			var d = Math.max(rippler.outerWidth(), rippler.outerHeight());
			ink.css({height: 20, width: 20});
		}
		// get click coordinates
		var x = e.pageX - rippler.offset().left - ink.width()/2;
		var y = e.pageY - rippler.offset().top - ink.height()/2;
		// set .ink position and add class .animate
		ink.css({
		  top: y+'px',
		  left:x+'px'
		}).addClass("animate");
		setTimeout(function(){ 
			ink.remove();
		}, 1500);
	})
	
	//-- Radio Ripple Effect --//
	$(".pmd-radio-pmd-ripple-effect").on('mousedown', function(e) {
		var rippler = $(this);
		$('.ink').remove();
		// create .ink element if it doesn't exist
		if(rippler.find(".ink").length == 0) {
			rippler.append('<span class="ink"></span>');
		}

		var ink = rippler.find(".ink");

		// prevent quick double clicks
		ink.removeClass("animate");

		// set .ink diametr
		if(!ink.height() && !ink.width())
		{
			var d = Math.max(rippler.outerWidth(), rippler.outerHeight());
			ink.css({height: 15, width: 15});
		}
		// get click coordinates
		var x = e.pageX - rippler.offset().left - ink.width()/2;
		var y = e.pageY - rippler.offset().top - ink.height()/2;

		// set .ink position and add class .animate
		ink.css({
		  top: y+'px',
		  left:x+'px'
		}).addClass("animate");
		setTimeout(function(){ 
			ink.remove();
		}, 1500);
	})
	
	function reposition() {
		var modal = $(this),
			dialog = modal.find('.modal-dialog');
			modal.css('display', 'block');
			dialog.css("margin-top", Math.max(0, ($(window).height() - dialog.height()) / 2));
			$(".modal .actions").css("margin-top", Math.max(0, ($(window).height() - dialog.height()) / 2));
	}
	
	// Reposition when a modal is shown
	$('.modal').on('show.bs.modal', reposition);
	
	$(window).on('resize', function() {
		$('.modal:visible').each(reposition);
	});
	
	$('.modal').on('shown.bs.modal', function (e) {
		$('#pmdTab').pmdTab();
	})
	
});