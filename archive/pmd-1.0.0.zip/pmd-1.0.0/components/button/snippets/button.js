<!-- jquery js -->
<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>

<!-- Propeller ripple effect js -->
<script type="text/javascript" src="http://demophp.digi-corp.com/CreativeZone/Websites/Propeller/HTML/components/button/js/ripple-effect.js"></script>